package com.example.myapplication

import retrofit2.http.GET
import retrofit2.http.Query

data class Product(
    val position: Int = 0,
    val title: String = "",
    val link: String? = null,
    val displayed_link: String = "",
    val snippet: String = "",
    val source: String = "",
    val price: String = "Sprawdź cenę",
    val thumbnail: String? = null
)

data class SerpApiResponse(
    val shopping_results: List<Product>
)

interface ApiService {
    @GET("search.json")
    suspend fun searchProducts(
        @Query("engine") engine: String,
        @Query("q") q: String,
        @Query("api_key") apiKey: String
    ): SerpApiResponse
}
