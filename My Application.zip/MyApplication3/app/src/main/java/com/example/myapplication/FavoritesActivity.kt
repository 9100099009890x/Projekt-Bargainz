package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FavoritesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyText: TextView
    private lateinit var backButton: ImageButton
    private lateinit var progressBar: ProgressBar
    private lateinit var favoritesAdapter: ProductAdapter
    private lateinit var sharedPrefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)

        sharedPrefs = getSharedPreferences("bargainz_favorites", Context.MODE_PRIVATE)
        initViews()
        setupRecyclerView()
        loadFavorites()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.favoritesRecyclerView)
        emptyText = findViewById(R.id.emptyFavoritesText)
        backButton = findViewById(R.id.backButton)
        progressBar = findViewById(R.id.progressBar)

        backButton.setOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        favoritesAdapter = ProductAdapter(
            emptyList(),
            onItemClick = { product -> openStore(product) },
            onFavoriteClick = { _, _ ->
                // Odświeżenie po usunięciu z koszyka
                Handler(Looper.getMainLooper()).postDelayed({
                    loadFavorites()
                }, 300)
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = favoritesAdapter
    }

    // ====================== POPRAWIONA FUNKCJA ======================
    private fun loadFavorites() {
        favoritesAdapter.updateProducts(emptyList())
        progressBar.visibility = View.VISIBLE
        emptyText.visibility = View.GONE
        recyclerView.visibility = View.GONE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Tylko prawdziwe ulubione (bez miniaturek i pomocniczych kluczy)
                val favoriteEntries = sharedPrefs.all.filter { entry ->
                    entry.value == true &&
                            !entry.key.contains("_thumbnail") &&
                            !entry.key.contains("_title") &&      // na przyszłość
                            !entry.key.contains("_price")
                }

                if (favoriteEntries.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        progressBar.visibility = View.GONE
                        emptyText.text = "Koszyk jest pusty\n\nKliknij gwiazdkę ⭐\naby dodać produkty"
                        emptyText.visibility = View.VISIBLE
                        recyclerView.visibility = View.GONE
                    }
                    return@launch
                }

                val allFavorites = mutableListOf<Product>()

                favoriteEntries.forEach { entry ->
                    val productId = entry.key

                    val title = extractTitleFromId(productId)
                    val price = extractPriceFromId(productId)
                    val thumbnail = sharedPrefs.getString("${productId}_thumbnail", null)

                    val favoriteProduct = Product(
                        position = 0,
                        title = title,
                        price = price,
                        source = "Koszyk",
                        thumbnail = thumbnail,
                        displayed_link = "Zapisane w koszyku",
                        snippet = "Dodane do koszyka",
                        link = null
                    )
                    allFavorites.add(favoriteProduct)
                }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    favoritesAdapter.updateProducts(allFavorites)
                    recyclerView.visibility = View.VISIBLE
                    emptyText.visibility = View.GONE
                }

            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    emptyText.text = "Błąd ładowania koszyka"
                    emptyText.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    Toast.makeText(this@FavoritesActivity, "Błąd: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // Poprawione funkcje wyciągania danych (działają nawet gdy cena zawiera spacje i zł)
    private fun extractTitleFromId(productId: String): String {
        if (!productId.contains("_")) return productId
        val lastIndex = productId.lastIndexOf('_')
        return productId.substring(0, lastIndex).replace("_", " ")
    }

    private fun extractPriceFromId(productId: String): String {
        if (!productId.contains("_")) return "Sprawdź cenę"
        val lastIndex = productId.lastIndexOf('_')
        val pricePart = productId.substring(lastIndex + 1)
        return if (pricePart.isNotEmpty()) pricePart else "Sprawdź cenę"
    }

    private fun openStore(product: Product) {
        try {
            val searchUrl = "https://www.google.com/search?q=${product.title?.replace(" ", "+") ?: ""}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Błąd otwarcia linku", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }
}