package com.example.myapplication

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ProductAdapter(
    private var products: List<Product>,
    private val onItemClick: (Product) -> Unit,
    private val onFavoriteClick: (Product, Boolean) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    private lateinit var context: Context
    private lateinit var sharedPrefs: SharedPreferences

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.productImage)
        val nameText: TextView = itemView.findViewById(R.id.productName)
        val priceText: TextView = itemView.findViewById(R.id.productPrice)
        val storeText: TextView = itemView.findViewById(R.id.productStore)
        val snippetText: TextView = itemView.findViewById(R.id.productSnippet)
        val favoriteIcon: ImageView = itemView.findViewById(R.id.favoriteIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        context = parent.context
        sharedPrefs = context.getSharedPreferences("bargainz_favorites", Context.MODE_PRIVATE)
        val view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]

        // Zdjęcie
        if (!product.thumbnail.isNullOrEmpty()) {
            Glide.with(context)
                .load(product.thumbnail)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .override(420, 240)
                .centerCrop()
                .into(holder.imageView)
        } else {
            holder.imageView.setImageResource(R.drawable.ic_launcher_background)
        }

        // Teksty
        holder.nameText.text = product.title ?: "Brak nazwy"
        holder.priceText.text = product.price ?: "Sprawdź cenę"
        holder.storeText.text = "${product.source ?: "Sklep"} • ${product.displayed_link ?: ""}"
        holder.snippetText.text = product.snippet ?: ""

        // Gwiazda
        val productId = generateProductId(product)
        val isFavorite = sharedPrefs.getBoolean(productId, false)

        holder.favoriteIcon.setImageResource(
            if (isFavorite) R.drawable.star_filled_black else R.drawable.star_filled
        )

        holder.itemView.setOnClickListener { onItemClick(product) }

        holder.favoriteIcon.setOnClickListener {
            val newState = !isFavorite

            holder.favoriteIcon.setImageResource(
                if (newState) R.drawable.star_filled_black else R.drawable.star_filled
            )

            val editor = sharedPrefs.edit()
            if (newState) {
                editor.putBoolean(productId, true)
                editor.putString("${productId}_title", product.title ?: "")
                editor.putString("${productId}_price", product.price ?: "")
                if (!product.thumbnail.isNullOrEmpty()) {
                    editor.putString("${productId}_thumbnail", product.thumbnail)
                }
            } else {
                editor.remove(productId)
                editor.remove("${productId}_title")
                editor.remove("${productId}_price")
                editor.remove("${productId}_thumbnail")
            }
            editor.apply()

            onFavoriteClick(product, newState)
        }
    }

    override fun getItemCount() = products.size

    // NAJLEPSZA WERSJA generateProductId
    private fun generateProductId(product: Product): String {
        val titleClean = product.title
            ?.replace(" ", "_")
            ?.replace(Regex("[^a-zA-Z0-9_]"), "")
            ?.take(60) ?: "unknown"

        val priceClean = product.price
            ?.replace(Regex("[^0-9.,zł]"), "")
            ?.replace(",", ".")
            ?.take(20) ?: "0"

        return "${titleClean}_$priceClean"
    }

    fun updateProducts(newProducts: List<Product>) {
        products = newProducts
        notifyDataSetChanged()
    }
}