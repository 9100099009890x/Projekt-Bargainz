package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    // 🎯 WSZYSTKIE WIDOKI
    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var sortPriceAscButton: Button
    private lateinit var sortPriceDescButton: Button
    private lateinit var sortNewestButton: Button
    private lateinit var clearSortButton: Button
    private lateinit var sortButtonsContainer: LinearLayout
    private lateinit var recyclerView: RecyclerView
    private lateinit var popularSearchesFab: FloatingActionButton
    private lateinit var cartButton: ImageView
    private lateinit var cartBadge: TextView

    private lateinit var adapter: ProductAdapter

    // 🔥 API
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://serpapi.com/")
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService = retrofit.create(ApiService::class.java)

    private var originalProducts: List<Product> = emptyList()
    private var currentSortType: SortType = SortType.NONE

    enum class SortType {
        NONE, PRICE_ASC, PRICE_DESC, NEWEST
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupRecyclerView()
        setupSearch()
        setupSortButtons()
        setupPopularSearchesFab()
        setupCartButton()
        updateCartBadge()
    }

    private fun initViews() {
        searchEditText = findViewById(R.id.searchEditText)
        searchButton = findViewById(R.id.searchButton)
        sortPriceAscButton = findViewById(R.id.sortPriceAscButton)
        sortPriceDescButton = findViewById(R.id.sortPriceDescButton)
        sortNewestButton = findViewById(R.id.sortNewestButton)
        clearSortButton = findViewById(R.id.clearSortButton)
        sortButtonsContainer = findViewById(R.id.sortButtonsContainer)
        recyclerView = findViewById(R.id.recyclerView)
        popularSearchesFab = findViewById(R.id.popularSearchesFab)
        cartButton = findViewById(R.id.cartButton)
        cartBadge = findViewById(R.id.cartBadge)
    }

    private fun setupPopularSearchesFab() {
        popularSearchesFab.visibility = View.GONE
        popularSearchesFab.setOnClickListener {
            showPopularSearchesDialog()
        }
    }

    private fun showPopularSearchesDialog() {
        val popularSearches = arrayOf(
            "iPhone 16", "Samsung Galaxy", "AirPods", "Nike Air Force",
            "PS5", "Laptop gamingowy", "iPad Pro"
        )
        AlertDialog.Builder(this)
            .setTitle("🔥 Popularne wyszukiwania")
            .setItems(popularSearches) { _, which ->
                val query = popularSearches[which]
                searchEditText.setText(query)
                searchProducts(query)
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun updateFabVisibility(hasResults: Boolean) {
        popularSearchesFab.visibility = if (hasResults) View.GONE else View.VISIBLE
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(
            emptyList(),
            onItemClick = { product -> openStore(product) },
            onFavoriteClick = { product, isAdded ->
                if (isAdded) {
                    Toast.makeText(this, "⭐ Dodano do koszyka: ${product.title}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "💔 Usunięto z koszyka: ${product.title}", Toast.LENGTH_SHORT).show()
                }
                updateCartBadge()
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupCartButton() {
        cartButton.setOnClickListener {
            val intent = Intent(this, FavoritesActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updateCartBadge() {
        val count = getFavoritesCount()
        cartBadge.text = count.toString()
        cartBadge.visibility = if (count > 0) View.VISIBLE else View.GONE
        cartButton.setColorFilter(
            if (count > 0) 0xFFFFFFFF.toInt() else 0xFFCCCCCC.toInt()
        )
    }

    private fun getFavoritesCount(): Int {
        val prefs = getSharedPreferences("bargainz_favorites", Context.MODE_PRIVATE)
        return prefs.all.count { it.value == true }
    }

    private fun setupSearch() {
        searchButton.setOnClickListener {
            val query = searchEditText.text.toString().trim()
            if (query.isNotEmpty()) {
                searchProducts(query)
            } else {
                Toast.makeText(this, "💡 Wpisz nazwę produktu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupSortButtons() {
        sortPriceAscButton.setOnClickListener {
            sortProducts(SortType.PRICE_ASC)
            updateSortButtonStates()
        }

        sortPriceDescButton.setOnClickListener {
            sortProducts(SortType.PRICE_DESC)
            updateSortButtonStates()
        }

        sortNewestButton.setOnClickListener {
            sortProducts(SortType.NEWEST)
            updateSortButtonStates()
        }

        clearSortButton.setOnClickListener {
            currentSortType = SortType.NONE
            adapter.updateProducts(originalProducts)
            updateSortButtonStates()
            sortButtonsContainer.visibility = View.GONE
            Toast.makeText(this, "🔄 Sortowanie wyczyszczone", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateSortButtonStates() {
        val buttons = listOf(sortPriceAscButton, sortPriceDescButton, sortNewestButton)

        // Wszystkie przyciski wracają do domyślnego stylu
        buttons.forEach {
            it.setBackgroundResource(R.drawable.button_sort_default)
            it.setTextColor(0xFF1E293B.toInt())
        }

        when (currentSortType) {
            SortType.PRICE_ASC, SortType.PRICE_DESC -> {
                val activeBtn = if (currentSortType == SortType.PRICE_ASC) sortPriceAscButton else sortPriceDescButton
                activeBtn.setBackgroundResource(R.drawable.button_sort_orange)
                activeBtn.setTextColor(0xFFFFFFFF.toInt())
            }
            SortType.NEWEST -> {
                sortNewestButton.setBackgroundResource(R.drawable.button_sort_blue)
                sortNewestButton.setTextColor(0xFFFFFFFF.toInt())
            }
            else -> {}
        }
    }

    private fun searchProducts(query: String) {
        searchButton.text = "🔍 Szukam..."
        searchButton.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = apiService.searchProducts(
                    engine = "google_shopping",
                    q = query,
                    apiKey = "ab6789885c997bfd560a4b3901cc094180ad30941decab843262748e61e44acc"
                )

                withContext(Dispatchers.Main) {
                    val resultsCount = response.shopping_results.size
                    if (resultsCount > 0) {
                        originalProducts = response.shopping_results
                        currentSortType = SortType.NONE
                        adapter.updateProducts(originalProducts)
                        sortButtonsContainer.visibility = View.VISIBLE
                        updateFabVisibility(true)
                        Toast.makeText(this@MainActivity, "✅ Znaleziono ${resultsCount} ofert!", Toast.LENGTH_SHORT).show()
                    } else {
                        updateFabVisibility(false)
                        Toast.makeText(this@MainActivity, "ℹ️ Brak ofert - spróbuj inne hasło!", Toast.LENGTH_LONG).show()
                    }
                    searchButton.text = "🔍 SZUKAJ"
                    searchButton.isEnabled = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    updateFabVisibility(false)
                    Toast.makeText(this@MainActivity, "🌐 ❌ Błąd sieci: ${e.message}", Toast.LENGTH_LONG).show()
                    searchButton.text = "🔍 SZUKAJ"
                    searchButton.isEnabled = true
                }
            }
        }
    }

    private fun sortProducts(sortType: SortType) {
        if (originalProducts.isEmpty()) return

        val sortedProducts = when (sortType) {
            SortType.PRICE_ASC -> originalProducts.sortedBy { parsePrice(it.price ?: "") }
            SortType.PRICE_DESC -> originalProducts.sortedByDescending { parsePrice(it.price ?: "") }
            SortType.NEWEST -> originalProducts.sortedByDescending { it.position }
            else -> originalProducts
        }

        adapter.updateProducts(sortedProducts)
        currentSortType = sortType
    }

    private fun parsePrice(priceText: String): Double {
        return try {
            val cleanPrice = priceText.replace(Regex("[^0-9.,zł]"), "").replace(",", ".").replace("zł", "")
            cleanPrice.toDoubleOrNull() ?: Double.MAX_VALUE
        } catch (e: Exception) {
            Double.MAX_VALUE
        }
    }

    private fun openStore(product: Product) {
        try {
            val directLink = product.link
            if (!directLink.isNullOrEmpty() && !directLink.contains("google.com")) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(directLink))
                startActivity(intent)
                return
            }

            val searchUrl = "https://www.google.com/search?q=${product.title?.replace(" ", "+") ?: ""}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "❌ Błąd otwarcia sklepu", Toast.LENGTH_SHORT).show()
        }
    }
}