// Top-level build file where you can add configuration options common to all sub-modules/scripts.
plugins {
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
}
